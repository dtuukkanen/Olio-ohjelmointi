package main;

public class Enrollment {
    private int grade = -1;

    public int getGrade() {
        return grade;
    }
}
